# DeepSeek Free Chat API — Railway Deployment Package

OpenAI-compatible REST API server for **chat.deepseek.com** (no official API key needed).
Is server ko koi bhi OpenAI-supporting app (Chatbox, LobeChat, NextChat, LangChain,
n8n, apni web/app) se connect kar sakti hai — bas `base_url` change karna hota hai.

> **ZIP ko direct Railway pe upload NAHI kar sakte** — Railway sirf **GitHub repo**
> ya **Railway CLI** se deploy karta hai. Neeche dono tareeqay step-by-step diye hain.

---

## 📁 Package me kya hai

| File | Kaam |
|------|------|
| `deepseek_rest_api.py` | Main FastAPI server (OpenAI-compatible endpoints) |
| `deepseek_web_chat.py` | DeepSeek web engine (PoW, SSE stream, vision) |
| `sha3_wasm_bg.wasm` | PoW solver — **saath rakhna zaroori hai!** |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Railway build config (auto-detect ho jata hai) |
| `railway.json` | Railway start command + healthcheck |
| `Procfile` | Backup start command (agar Nixpacks use ho) |
| `.env.example` | Local run ke liye env var template |
| `README.md` | Ye doc |

---

## 🔑 Step 0: Apna Token Nikaalo (sab se pehle ye chahiye)

1. Browser me **chat.deepseek.com** kholo aur login karo
2. Keyboard pe **F12** dabao (DevTools khulega)
3. Upar **Application** tab > left side **Local Storage** > `https://chat.deepseek.com`
4. Key `userToken` dhoondo > us ke andar jo **`value`** hai wo copy karo
   (lambi si string hoti hai — ye hi tumhara token hai)
5. ⚠️ Ye token secret hai — kisi ko chat/paste mat karo!

---

## 🚀 Method 1: GitHub se Deploy (RECOMMENDED — sab se aasan)

### 1. Files GitHub pe daalo
- [github.com/new](https://github.com/new) pe jao → naya repo banao (private rakhna better hai)
- ZIP ko unzip karo → **saari files** repo me upload karo (Add file > Upload files > drag & drop)
- **Commit changes** dabao

### 2. Railway pe project banao
- [railway.com](https://railway.com) pe jao → **Login with GitHub**
- **New Project** > **Deploy from GitHub repo** > apna repo select karo
- Railway khud hi `Dockerfile` + `requirements.txt` dekh kar build kar dega (2-4 min)

### 3. Token daalo (Environment Variables)
- Apne service pe click karo → **Variables** tab
- Ye variables add karo:

| Variable | Value | Zaroori? |
|----------|-------|----------|
| `DEEPSEEK_USER_TOKEN` | (Step 0 wala token) | ✅ HAAN |
| `REST_API_KEY` | koi bhi secret password | Optional (recommended) |

- Save karte hi Railway khud redeploy kar dega

### 4. Public URL nikaalo
- Service → **Settings** tab → **Networking** section → **Generate Domain**
- Railway tumhe ek URL dega jaise: `https://deepseek-api-production-xxxx.up.railway.app`
- Bas! Ab ye URL duniya se accessible hai 🎉

### 5. Test karo
```
https://TUMHARA-URL.up.railway.app/healthz        -> {"status":"ok"}
https://TUMHARA-URL.up.railway.app/               -> ready-made chat UI (browser me kholo!)
```

---

## 🚀 Method 2: Railway CLI se Deploy (bina GitHub)

```bash
# 1. CLI install karo (Node.js chahiye)
npm install -g @railway/cli

# 2. Login
railway login

# 3. ZIP ko unzip karo, us folder me jao
cd deepseek-chat-api-railway

# 4. Naya project banao aur deploy
railway init
railway up

# 5. Token variable daalo (GUI khol dega)
railway variables --set "DEEPSEEK_USER_TOKEN=yahan-apna-token"
railway variables --set "REST_API_KEY=koi-secret-password"

# 6. Public URL banao
railway domain

# 7. Live logs dekhne ke liye
railway logs
```

---

## 💻 Local pe Test karna (Railway se pehle)

```bash
pip install -r requirements.txt

# .env.example ko ".env" banao, token daalo — ya seedha aise chalao:
python3 deepseek_rest_api.py --token "APNA_USERTOKEN"

# Browser: http://127.0.0.1:8000/
```

---

## 📡 API Endpoints

| Endpoint | Kaam |
|----------|------|
| `GET /` | Ready-made chat UI (browser me kholo) |
| `GET /healthz` | Health check (Railway isko use karta hai) |
| `GET /v1/models` | Available models list |
| `POST /v1/chat/completions` | Chat (stream + non-stream, vision support) |

### curl test:
```bash
curl https://TUMHARA-URL.up.railway.app/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer REST_API_KEY_WALA_PASSWORD" \
  -d '{
    "model": "deepseek-chat",
    "messages": [{"role": "user", "content": "Assalam o Alaikum!"}]
  }'
```
(agar `REST_API_KEY` set nahi kiya to Authorization header ki zaroorat nahi)

### OpenAI Python SDK se:
```python
from openai import OpenAI

client = OpenAI(
    base_url="https://TUMHARA-URL.up.railway.app/v1",
    api_key="REST_API_KEY_wala_password"   # ya kuch bhi, agar key set nahi
)

# Simple chat
r = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{"role": "user", "content": "Pakistan ka tareekh batao"}],
)
print(r.choices[0].message.content)

# Streaming (live typing)
stream = client.chat.completions.create(
    model="deepseek-reasoner",
    messages=[{"role": "user", "content": "AI kya hai?"}],
    stream=True,
)
for chunk in stream:
    d = chunk.choices[0].delta
    if d.content:
        print(d.content, end="", flush=True)

# Image bhejna (vision)
import base64
img = base64.b64encode(open("photo.jpg", "rb").read()).decode()
r = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{"role": "user", "content": [
        {"type": "text", "text": "Is photo me kya hai?"},
        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img}"}},
    ]}],
)
print(r.choices[0].message.content)
```

### Chatbox / LobeChat / NextChat apps me:
- Provider: **OpenAI**
- **Base URL / API Host**: `https://TUMHARA-URL.up.railway.app/v1` (ya bina `/v1` ke, app pe depend karta hai)
- **API Key**: jo `REST_API_KEY` set kiya (ya kuch bhi)
- **Model**: `deepseek-chat`, `deepseek-reasoner`, `deepseek-expert` (manually type karo)

---

## 🤖 Available Models

| Model | Kya hai |
|-------|---------|
| `deepseek-chat` | Fast model (normal chat) |
| `deepseek-reasoner` | DeepThink — R1-style sochne wala (`reasoning_content` field me soch deta hai) |
| `deepseek-expert` | Zyada powerful model |
| `deepseek-expert-reasoner` | Expert + DeepThink |
| `deepseek-chat-search` | Fast model + web search |
| `deepseek-reasoner-search` | DeepThink + web search |

---

## 🔧 Troubleshooting

| Problem | Wajah | Hal |
|---------|-------|-----|
| `403` / Cloudflare/WAF error | Railway ka IP block ho gaya | Railway service → Settings → **Region change karo** (US West try karo) → redeploy |
| `40003 INVALID_TOKEN` | Token expire/refresh ho gaya | Browser me DeepSeek **logout → login** karo → **naya userToken** lo → Variables me update karo |
| `40002 Missing Token` | `DEEPSEEK_USER_TOKEN` variable missing/galat | Variables tab me check karo — spelling aur value bilkul sahi honi chahiye |
| Server 502 / crash ho jata hai | Token nahi laga hua | Railway **Deployments → Logs** dekho |
| Reply aa hi nahi raha / hang | PoW challenge slow | Kuch second ruko; Railway auto-restart karega (`restartPolicy`) |
| Railway pe deploy hi nahi hota | `sha3_wasm_bg.wasm` upload karna bhool gaye | Saari files repo me honi chahiye — `.wasm` file bhi! |

**Railway free plan note:** Free/trial plan pe server kuch dinon ke baad sleep ho jata hai
(first request slow aayegi). Hobby plan ($5) pe hamesha on rehta hai.

---

## 🔒 Security (Zaroori!)

1. **Token kabhi code me hard-code mat karo** — hamesha Railway Variables me daalo
2. **`REST_API_KEY` set karo** warna duniya ka koi bhi tumhara server free use karega
   (aur Railway usage bill barh jayega)
3. DeepSeek ka **unofficial API** hai — rate limits hain, aur kabhi bhi protocol change
   ho sakta hai. Heavy/production kaam ke liye official DeepSeek API lo
4. Agar tumne token kisi public jagah paste kiya hua hai to **abhi logout→login karo**
   — purana token mar jayega aur naya safe rahega

---

## 📖 Built-in docs (new)

Open `https://TUMHARA-URL.up.railway.app/docs` for the full API docs page (base URL,
models, curl / Python / JS examples). Swagger is at `/swagger`.
Leave `REST_API_KEY` empty and the API needs no key at all; any OpenAI client can
send any string as the key. The routes also work without the `/v1` prefix.
