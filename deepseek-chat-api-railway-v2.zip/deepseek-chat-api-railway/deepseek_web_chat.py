#!/usr/bin/env python3
"""
DeepSeek web-chat client that authenticates with browser COOKIES (no API key).

Talks directly to chat.deepseek.com's internal web API:

  1. POST /api/v0/chat_session/create        -> chat session id
  2. POST /api/v0/chat/create_pow_challenge  -> proof-of-work challenge
  3. solve it with DeepSeek's own sha3 WASM  -> x-ds-pow-response header (base64)
  4. POST /api/v0/chat/completion            -> SSE stream (JSON-patch frames)
  5. (optional) POST /api/v0/file/upload     -> image file id for vision queries

Usage:
  python deepseek_web_chat.py "What is 2+2?"
  python deepseek_web_chat.py --image pic.jpg "What is in this image?"
  python deepseek_web_chat.py --thinking "..."          # DeepThink (R1) mode
  python deepseek_web_chat.py --search "..."            # web search enabled
  python deepseek_web_chat.py --expert "..."            # slower/stronger model
  python deepseek_web_chat.py --token <userToken> "..." # fallback: Bearer auth
  python deepseek_web_chat.py --cookies cookies.json "..."  # refresh cookies
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import struct
import sys
import threading
import time
import uuid
from pathlib import Path

import wasmtime

BASE = "https://chat.deepseek.com"
COMPLETION_PATH = "/api/v0/chat/completion"
UPLOAD_PATH = "/api/v0/file/upload_file"  # single 'file' form field, needs its own PoW
WASM_PATH = Path(__file__).resolve().parent / "sha3_wasm_bg.wasm"

# --- browser session cookies (DevTools -> Application -> Cookies -> chat.deepseek.com)
COOKIES = {
    "aws-waf-token": (
        "7f74668c-4815-416c-8aaa-da16eefb3570:BQoAqCltPrCyBgAA:w6uzrk8PDWH5sU6pNlDW/"
        "jyor0lbgLY3fy3mvf33866EI2DPZXE57Z8IfR+vgOI7f9RHrcYhthcoLQFEo9rn0n0+Ni8S9YwksJV2uQw97lVd2Q3"
        "wWdRzLwyxw24MGi9+fTY4k5lUPNpl/kK+VqiNeydM1oGBYZ3GfBQtzFUQSyfeLp6VrR3bESwE0c9crluoCu8EJobD2"
        "+eRisRTqV71pikQhdQiXNBkmoigKNdrnYn4PV9uDJKFUE7hQ2iAPeg4hTGEgbU5KkkU+j9gXX5wu4ZeSsFAYgrPFKE"
        "v2L8m3bpUo+Tqkbw3OWdtPLV4"
    ),
    "smidV2": "20261021001952a71c7a8f948093eceebe61330e9f8af000f45699a3f0276c0",
    ".thumbcache_6b2e5483f9d858d7c661c5e276b6a6ae": (
        "QMluYf+JyDzrESFcGQwN4w5upGCdvuWx64likPGtFBhvM/bhsTSZL0qLfK/ofDqfdXPMQ3SnUbKlMmVNENm"
        "+lg%3D%3D"
    ),
    "ds_session_id": "ad31c72ba7024fb4a7a24d1372b11c90",
}

BROWSER_HEADERS = {
    "accept": "*/*",
    "content-type": "application/json",
    "origin": BASE,
    "referer": f"{BASE}/",
    "x-app-version": "2.0.0",
    "x-client-version": "2.0.0",
    "x-client-platform": "web",
    "x-client-locale": "en_US",
    "x-client-bundle-id": "com.deepseek.chat",
    "x-client-timezone-offset": "18000",  # UTC+5 (Asia/Karachi)
    "user-agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
    ),
}


def dbg(enabled, *a):
    if enabled:
        print("[dbg]", *a, file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Proof-of-work: run DeepSeek's own sha3_wasm_bg.wasm (DeepSeekHashV1)
# ---------------------------------------------------------------------------
class DeepSeekPow:
    def __init__(self, wasm_path: Path = WASM_PATH):
        self._store = wasmtime.Store()
        module = wasmtime.Module.from_file(self._store.engine, str(wasm_path))
        self._inst = wasmtime.Instance(self._store, module, [])
        exp = self._inst.exports(self._store)
        self._memory = exp["memory"]
        self._solve = exp["wasm_solve"]
        self._malloc = exp["__wbindgen_export_0"]
        self._add_to_stack = exp["__wbindgen_add_to_stack_pointer"]

    def _write_str(self, text: str):
        data = text.encode("utf-8")
        ptr = self._malloc(self._store, len(data), 1)
        self._memory.write(self._store, data, ptr)
        return ptr, len(data)

    def solve(self, challenge: str, prefix: str, difficulty: float):
        """Mirror the website's wasm-bindgen call:
        wasm_solve(retptr, challenge_ptr, challenge_len, prefix_ptr, prefix_len, difficulty)
        16-byte return slot: i32 status at +0, f64 answer at +8.
        """
        retptr = self._add_to_stack(self._store, -16)
        try:
            c_ptr, c_len = self._write_str(challenge)
            p_ptr, p_len = self._write_str(prefix)
            self._solve(self._store, retptr, c_ptr, c_len, p_ptr, p_len, float(difficulty))
            raw = self._memory.read(self._store, retptr, retptr + 16)
            status = struct.unpack("<i", raw[:4])[0]
            # Browser glue: `return 0 === o ? void 0 : s` -> status==0 means NO
            # solution; any non-zero status means the f64 answer is valid.
            if status == 0:
                return None
            return struct.unpack("<d", raw[8:16])[0]
        finally:
            self._add_to_stack(self._store, 16)

    def make_header(self, challenge: dict) -> str:
        """Build the base64 x-ds-pow-response header value."""
        prefix = f"{challenge['salt']}_{challenge['expire_at']}_"
        t0 = time.time()
        answer = self.solve(challenge["challenge"], prefix, challenge["difficulty"])
        if answer is None:
            raise RuntimeError("PoW solver returned no answer (challenge expired / wasm mismatch?)")
        dbg_print = f"solved difficulty={challenge['difficulty']} in {time.time()-t0:.2f}s"
        payload = {
            "algorithm": challenge["algorithm"],
            "challenge": challenge["challenge"],
            "salt": challenge["salt"],
            "answer": int(answer),
            "signature": challenge["signature"],
            "target_path": challenge["target_path"],
        }
        raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        header = base64.b64encode(raw).decode("ascii")
        DeepSeekPow._last_dbg = dbg_print
        return header


# ---------------------------------------------------------------------------
# HTTP plumbing (curl_cffi for a real Chrome TLS fingerprint -> friendlier to AWS WAF)
# ---------------------------------------------------------------------------
def make_http(debug: bool, token: str | None, cookies: dict):
    try:
        from curl_cffi import requests as creq

        s = creq.Session(impersonate="chrome", headers=dict(BROWSER_HEADERS),
                         cookies=cookies, timeout=60)
        if debug:
            dbg(True, "HTTP engine: curl_cffi (chrome TLS impersonation)")
        return s
    except Exception as e:  # pragma: no cover
        dbg(debug, "curl_cffi unavailable, falling back to requests:", e)
        import requests

        s = requests.Session()
        s.headers.update(BROWSER_HEADERS)
        s.cookies.update(cookies)
        return s


def iter_lines_decoded(resp):
    for line in resp.iter_lines():
        if isinstance(line, bytes):
            line = line.decode("utf-8", errors="replace")
        yield line


def unwrap(resp, debug: bool) -> dict:
    """Parse a JSON API response, raising readable errors."""
    body = resp.text
    dbg(debug, "HTTP", resp.status_code, "content-type:", resp.headers.get("content-type", "?"))
    if resp.status_code == 403 and ("<html" in body[:200].lower() or "aws" in body[:500].lower()):
        raise RuntimeError(
            "Blocked by AWS WAF (403). Your aws-waf-token cookie may be expired, "
            "or bound to your browser IP/fingerprint. Re-copy fresh cookies."
        )
    if resp.status_code == 401:
        raise RuntimeError(
            "401 Unauthorized - the endpoint did not accept the provided credentials. "
            "Retry with --token <userToken> (see HOW TO GET YOUR TOKEN below)."
        )
    try:
        data = resp.json()
    except Exception:
        raise RuntimeError(f"Non-JSON response (HTTP {resp.status_code}): {body[:400]!r}")
    if data.get("code") in (40002, 40003):
        raise RuntimeError(
            f"Auth rejected (code={data.get('code')}). Browser cookies alone are NOT enough: "
            "chat.deepseek.com authenticates via 'Authorization: Bearer <userToken>' where "
            "userToken lives in localStorage, not cookies.\n"
            "  HOW TO GET YOUR TOKEN:\n"
            "    1. Open https://chat.deepseek.com and make sure you are logged in\n"
            "    2. Press F12 -> Application tab -> Local Storage -> https://chat.deepseek.com\n"
            "    3. Copy the 'value' string inside the 'userToken' key (the long JWT-looking string)\n"
            "    4. Run:  python deepseek_web_chat.py --token <that-string> \"your prompt\"\n"
            "       (or:  export DEEPSEEK_USER_TOKEN=<that-string>  and drop the --token flag)"
        )
    if data.get("code") != 0:
        raise RuntimeError(f"DeepSeek API error code={data.get('code')} msg={data.get('msg') or data}")
    biz = (data.get("data") or {}).get("biz_data")
    if biz is None:
        raise RuntimeError(f"Unexpected response shape: {json.dumps(data)[:400]}")
    return biz


# ---------------------------------------------------------------------------
# SSE stream parsing (JSON-patch style frames)
# ---------------------------------------------------------------------------
def _kind_of(fragment_type):
    t = (fragment_type or "").upper()
    if t == "RESPONSE":
        return "text"
    if "THINK" in t:
        return "reasoning"
    return None  # SEARCH_RESULT etc. -> ignored


def parse_sse(lines, debug=False):
    """Yield (kind, delta) tuples, kind in {'text', 'reasoning'}. Frame shapes:
      snapshot:      {"v": {"response": {"fragments": [{"type": "RESPONSE", "content": "..."}]}}}
      fragment add:  {"p": "response/fragments", "o": "APPEND",
                      "v": [{"type": "RESPONSE", "content": "360", ...}]}   (thinking -> answer)
      append:        {"p": "response/fragments/-1/content", "o": "APPEND", "v": " what"}
      bare:          {"v": "more"}                       (appends to the active fragment)
    Appends always target the LAST fragment ('-1'), so we track its type.
    """
    active_type = None
    emitted = set()
    message_id = None
    for line in lines:
        if not line or not line.startswith("data:"):
            continue
        payload = line[len("data:"):].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            obj = json.loads(payload)
        except json.JSONDecodeError:
            dbg(debug, "unparsable SSE frame:", payload[:200])
            continue
        v = obj.get("v")

        # Snapshot frame: full response object.
        if isinstance(v, dict) and "response" in v:
            resp_obj = v["response"]
            mid = resp_obj.get("message_id", resp_obj.get("id"))
            if isinstance(mid, int):
                message_id = mid
            frags = resp_obj.get("fragments", []) or []
            if frags:
                active_type = frags[-1].get("type")
            for frag in frags:
                fid = frag.get("id")
                if frag.get("content") and fid not in emitted:
                    emitted.add(fid)
                    kind = _kind_of(frag.get("type"))
                    if kind:
                        yield (kind, frag["content"])
            continue

        # New fragment(s) appended to the fragments array (thinking -> answer switch).
        if obj.get("p") == "response/fragments" and obj.get("o") == "APPEND" and isinstance(v, list):
            for frag in v:
                active_type = frag.get("type")
                fid = frag.get("id")
                if frag.get("content") and fid not in emitted:
                    emitted.add(fid)
                    kind = _kind_of(active_type)
                    if kind:
                        yield (kind, frag["content"])
            continue

        # Path-setting frames (message_id capture; content appends below).
        if "p" in obj and isinstance(obj.get("p"), str):
            p = obj["p"]
            if p.endswith("message_id") and isinstance(v, int):
                message_id = v
            if obj.get("o") == "APPEND" and isinstance(v, str) and p.endswith("content"):
                kind = _kind_of(active_type)
                if kind:
                    yield (kind, v)
                continue
            continue  # SET / BATCH / other path frames carry no text delta

        # Bare append to the current fragment (frames without a path).
        if isinstance(v, str) and active_type is not None:
            kind = _kind_of(active_type)
            if kind:
                yield (kind, v)

    # stash message id for the caller
    parse_sse.message_id = message_id


# ---------------------------------------------------------------------------
# Main chat flow
# ---------------------------------------------------------------------------
_POW = None
_POW_LOCK = threading.Lock()


def get_pow_solver():
    """Shared solver; wasmtime Store/Instance are not reentrant, so every
    make_header() call is serialised with _POW_LOCK."""
    global _POW
    if _POW is None:
        if not WASM_PATH.exists():
            raise RuntimeError(f"Missing WASM module: {WASM_PATH}")
        _POW = DeepSeekPow(WASM_PATH)
    return _POW


def pow_header_for(s, pow_solver, target_path, debug=False):
    """Fetch a fresh challenge for target_path and solve it (thread-safe)."""
    r = s.post(f"{BASE}/api/v0/chat/create_pow_challenge", json={"target_path": target_path})
    biz = unwrap(r, debug)
    with _POW_LOCK:
        header = pow_solver.make_header(biz["challenge"])
    dbg(debug, "pow:", getattr(DeepSeekPow, "_last_dbg", "?"))
    return header
def upload_file(s, pow_solver, image_path: str, debug: bool = False) -> str:
    """Upload an image to /api/v0/file/upload_file and return its file id.
    The form has a single 'file' field, and the request needs its own PoW
    header with target_path=/api/v0/file/upload_file (mirrors the web app).
    """
    path = Path(image_path)
    content = path.read_bytes()
    ctype = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
             ".webp": "image/webp", ".gif": "image/gif"}.get(path.suffix.lower(),
                                                              "image/jpeg")
    # PoW for the upload scene (its own target_path)
    pow_header = pow_header_for(s, pow_solver, UPLOAD_PATH, debug)

    # Build the multipart body manually (deterministic boundary, works with
    # both curl_cffi and requests; the form has a single 'file' field).
    boundary = "----DeepSeekFormBoundary" + uuid.uuid4().hex
    body = b"".join([
        f"--{boundary}\r\n".encode(),
        f'Content-Disposition: form-data; name="file"; filename="{path.name}"\r\n'.encode(),
        f"Content-Type: {ctype}\r\n\r\n".encode(),
        content, b"\r\n",
        f"--{boundary}--\r\n".encode(),
    ])

    headers = {"X-DS-PoW-Response": pow_header,
               "Content-Type": f"multipart/form-data; boundary={boundary}"}
    # Never let the session's default content-type (application/json) leak in.
    saved_ct = s.headers.pop("content-type", None)
    try:
        if type(s).__module__.startswith("curl_cffi"):
            r = s.post(f"{BASE}{UPLOAD_PATH}", data=body, headers=headers)
        else:
            r = s.post(f"{BASE}{UPLOAD_PATH}", data=body, headers=headers)
    finally:
        if saved_ct:
            s.headers["content-type"] = saved_ct
    biz = unwrap(r, debug)
    fid = biz.get("id") or (biz.get("file") or {}).get("id")
    if not fid:
        raise RuntimeError(f"Upload succeeded but no file id in response: {json.dumps(biz)[:300]}")
    return fid


def wait_file_ready(s, fid: str, debug: bool = False, timeout: float = 60.0):
    """Poll /api/v0/file/fetch_files until the uploaded file is parsed."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = s.get(f"{BASE}/api/v0/file/fetch_files", params={"file_ids": fid})
        try:
            files = ((r.json().get("data") or {}).get("biz_data") or {}).get("files") or []
        except Exception:
            files = []
        status = (files[0].get("status") if files else "") or ""
        dbg(debug, "file status:", status or "?")
        if status == "SUCCESS":
            return
        if status in ("FAILED", "ERROR", "REJECTED", "CONTENT_FILTER"):
            raise RuntimeError(f"File parsing failed on server (status={status})")
        time.sleep(1.2)
    raise RuntimeError("File parsing timed out")


def stream_chat(prompt: str, images=None, thinking: bool = False,
                search: bool = False, expert: bool = False, token: str | None = None,
                cookies: dict | None = None, debug: bool = False,
                chat_session_id: str | None = None, parent_message_id: int | None = None):
    """Yield (kind, delta) tuples from a DeepSeek web completion.

    kind: 'text' or 'reasoning'. After the stream is consumed,
    stream_chat.conversation_id holds '<session_id>:<message_id>' for resuming.
    Pass chat_session_id + parent_message_id to continue an existing thread.
    """
    cookies = dict(COOKIES) if cookies is None else cookies
    s = make_http(debug, token, cookies)
    if token:
        s.headers["authorization"] = f"Bearer {token}"
        dbg(debug, "auth mode: Bearer token + cookies")
    else:
        dbg(debug, "auth mode: cookies only")

    pow_solver = get_pow_solver()

    # -- 1. chat session (create or resume) ---------------------------------
    if chat_session_id:
        session_id = chat_session_id
        dbg(debug, "resuming session:", session_id, "parent:", parent_message_id)
    else:
        r = s.post(f"{BASE}/api/v0/chat_session/create", json={})
        session_id = unwrap(r, debug)["chat_session"]["id"]
        dbg(debug, "chat_session_id:", session_id)

    # -- 2. optional image uploads ------------------------------------------
    ref_file_ids = []
    for img in (images or []):
        fid = upload_file(s, pow_solver, img, debug)
        dbg(debug, "uploaded file id:", fid)
        wait_file_ready(s, fid, debug)
        ref_file_ids.append(fid)

    # -- 3. PoW challenge ----------------------------------------------------
    pow_header = pow_header_for(s, pow_solver, COMPLETION_PATH, debug)

    # -- 4. completion stream ------------------------------------------------
    body = {
        "chat_session_id": session_id,
        "parent_message_id": parent_message_id,
        "prompt": prompt,
        "ref_file_ids": ref_file_ids,
        "thinking_enabled": thinking,
        "search_enabled": search,
        "action": None,
        "preempt": False,
    }
    if chat_session_id is None:
        body["model_type"] = "expert" if expert else "default"
    dbg(debug, "completion body:", json.dumps(body)[:300])

    r = s.post(
        f"{BASE}{COMPLETION_PATH}",
        json=body,
        headers={"x-ds-pow-response": pow_header, "accept": "text/event-stream"},
        stream=True,
        timeout=(30, 300),
    )
    ctype = r.headers.get("content-type", "")
    if r.status_code != 200 or "event-stream" not in ctype:
        raise RuntimeError(f"completion: HTTP {r.status_code} {ctype}: {r.text[:400]!r}")

    for kind, delta in parse_sse(iter_lines_decoded(r), debug):
        yield (kind, delta)
    mid = getattr(parse_sse, "message_id", None)
    stream_chat.conversation_id = f"{session_id}:{mid}" if mid is not None else session_id


def chat(prompt: str, image: str | None, thinking: bool, search: bool,
         expert: bool, token: str | None, cookies: dict, debug: bool) -> str:
    """CLI helper: print the stream and return the full text reply."""
    chunks = []
    for kind, delta in stream_chat(prompt, images=[image] if image else None,
                                   thinking=thinking, search=search, expert=expert,
                                   token=token, cookies=cookies, debug=debug):
        if kind == "reasoning":
            print(f"\x1b[2m{delta}\x1b[0m", end="", flush=True)
        else:
            chunks.append(delta)
            print(delta, end="", flush=True)
    print(flush=True)
    print(f"--- conversation_id: {getattr(stream_chat, 'conversation_id', '?')}",
          file=sys.stderr, flush=True)
    return "".join(chunks)


def main():
    ap = argparse.ArgumentParser(description="DeepSeek web chat via browser cookies (no API key)")
    ap.add_argument("prompt", help="message to send")
    ap.add_argument("--image", help="path to an image to attach (vision query)")
    ap.add_argument("--thinking", action="store_true", help="enable DeepThink (R1) reasoning")
    ap.add_argument("--search", action="store_true", help="enable web search")
    ap.add_argument("--expert", action="store_true", help="use the 'expert' (stronger) model")
    ap.add_argument("--token", help="userToken from localStorage (fallback if cookie auth fails)")
    ap.add_argument("--cookies", help="path to a cookies JSON file to override built-ins")
    ap.add_argument("--debug", action="store_true", help="verbose diagnostics on stderr")
    args = ap.parse_args()

    cookies = dict(COOKIES)
    if args.cookies and Path(args.cookies).exists():
        raw = json.loads(Path(args.cookies).read_text())
        if isinstance(raw, list):  # cookie-editor export format
            cookies = {c["name"]: c["value"] for c in raw}
        else:
            cookies = raw

    token = args.token or os.environ.get("DEEPSEEK_USER_TOKEN")

    try:
        chat(args.prompt, args.image, args.thinking, args.search, args.expert,
             token, cookies, args.debug)
    except Exception as e:
        print(f"\n[ERROR] {e}", file=sys.stderr, flush=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
