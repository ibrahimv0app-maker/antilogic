DOCS_HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DeepSeek API Docs</title>
<style>
:root{--bg:#0f1117;--panel:#1a1d27;--line:#2a2e3d;--tx:#e8eaf2;--dim:#8b90a5;--acc:#4d6bfe}
@media(prefers-color-scheme:light){:root{--bg:#f7f8fb;--panel:#fff;--line:#dfe2ec;--tx:#1b1e2b;--dim:#5d6378}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.65 system-ui,Segoe UI,Roboto,sans-serif}
.wrap{max-width:860px;margin:0 auto;padding:28px 16px 80px}
h1{font-size:26px;margin:0 0 4px}h2{font-size:19px;margin:36px 0 10px;padding-top:8px;border-top:1px solid var(--line)}
p,li{color:var(--tx)}.dim{color:var(--dim)}
code{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;background:var(--panel);border:1px solid var(--line);border-radius:5px;padding:1px 5px}
pre{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px;overflow-x:auto;position:relative}
pre code{background:none;border:0;padding:0}
table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line)}
.base{display:flex;gap:8px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px 14px;margin:14px 0}
.base code{border:0;background:none;font-size:14px;flex:1;word-break:break-all}
button{background:var(--acc);color:#fff;border:0;border-radius:8px;padding:6px 12px;cursor:pointer;font-size:13px}
.pill{display:inline-block;font-size:12px;font-weight:600;padding:2px 8px;border-radius:99px;background:var(--acc);color:#fff;margin-right:6px}
a{color:var(--acc)}
</style></head><body><div class="wrap">
<h1>DeepSeek API</h1>
<p class="dim">OpenAI-compatible API. No API key required. Works with any OpenAI SDK or app.</p>
<div class="base"><span class="dim">Base URL</span><code id="b">__BASE__/v1</code><button onclick="navigator.clipboard.writeText(document.getElementById('b').textContent)">Copy</button></div>
<p>Use any string (or nothing) as the API key. <a href="/">Open the chat UI</a> · <a href="/swagger">Swagger</a></p>

<h2>Endpoints</h2>
<table>
<tr><th>Method</th><th>Path</th><th>Purpose</th></tr>
<tr><td><span class="pill">POST</span></td><td><code>/v1/chat/completions</code></td><td>Chat, streaming and non-streaming, images</td></tr>
<tr><td><span class="pill">GET</span></td><td><code>/v1/models</code></td><td>List models</td></tr>
<tr><td><span class="pill">GET</span></td><td><code>/healthz</code></td><td>Health check</td></tr>
</table>
<p class="dim">The same routes also work without the <code>/v1</code> prefix.</p>

<h2>Models</h2>
<table>
<tr><th>Model</th><th>Description</th></tr>
<tr><td><code>deepseek-chat</code></td><td>Fast model</td></tr>
<tr><td><code>deepseek-reasoner</code></td><td>DeepThink; reasoning returned in <code>reasoning_content</code></td></tr>
<tr><td><code>deepseek-expert</code></td><td>Stronger, slower model</td></tr>
<tr><td><code>deepseek-expert-reasoner</code></td><td>Expert with DeepThink</td></tr>
<tr><td><code>deepseek-chat-search</code></td><td>Fast model with web search</td></tr>
<tr><td><code>deepseek-reasoner-search</code></td><td>DeepThink with web search</td></tr>
</table>

<h2>curl</h2>
<pre><code>curl __BASE__/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"Hello!"}]}'</code></pre>
<p>Streaming: add <code>"stream": true</code> and use <code>curl -N</code>.</p>

<h2>Python</h2>
<pre><code>from openai import OpenAI

client = OpenAI(base_url="__BASE__/v1", api_key="none")

r = client.chat.completions.create(
    model="deepseek-chat",
    messages=[{"role": "user", "content": "Hello!"}],
)
print(r.choices[0].message.content)

# streaming + reasoning
for chunk in client.chat.completions.create(
        model="deepseek-reasoner", stream=True,
        messages=[{"role": "user", "content": "Why is the sky blue?"}]):
    d = chunk.choices[0].delta
    print(getattr(d, "reasoning_content", None) or d.content or "", end="")</code></pre>

<h2>JavaScript</h2>
<pre><code>import OpenAI from "openai";
const client = new OpenAI({ baseURL: "__BASE__/v1", apiKey: "none" });
const r = await client.chat.completions.create({
  model: "deepseek-chat",
  messages: [{ role: "user", content: "Hello!" }],
});
console.log(r.choices[0].message.content);</code></pre>

<h2>Images (vision)</h2>
<pre><code>{"model":"deepseek-chat","messages":[{"role":"user","content":[
  {"type":"text","text":"What is in this picture?"},
  {"type":"image_url","image_url":{"url":"data:image/jpeg;base64,..."}}
]}]}</code></pre>
<p>Both <code>data:</code> URLs and public <code>https://</code> image URLs are accepted.</p>

<h2>Chat apps</h2>
<p>In Chatbox, LobeChat, NextChat, Open WebUI, Cursor-style tools and similar: choose the OpenAI provider, set the API host to the Base URL above, enter any API key, and type a model name from the table.</p>

<h2>Notes</h2>
<ul>
<li><code>temperature</code>, <code>max_tokens</code> and similar parameters are accepted but ignored.</li>
<li><code>usage</code> token counts are always 0.</li>
<li>Function calling / tools are not supported.</li>
<li>Multi-turn chats are resumed server-side when you resend the full message history.</li>
<li>This runs on the DeepSeek web chat, so DeepSeek's own account limits and availability still apply.</li>
<li>Errors follow the OpenAI shape: <code>{"error":{"message":"...","type":"..."}}</code>.</li>
</ul>
</div></body></html>"""
