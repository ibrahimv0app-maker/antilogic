#!/usr/bin/env python3
"""
DeepSeek Free REST API - OpenAI-compatible server over chat.deepseek.com
(no official API key needed; uses the web endpoint + your userToken + cookies).

RUN:
  python3 deepseek_rest_api.py --token <userToken> --port 8000
  # or:  export DEEPSEEK_USER_TOKEN=<userToken> && python3 deepseek_rest_api.py

USE FROM ANY OpenAI SDK / CHATBOT APP:
  from openai import OpenAI
  client = OpenAI(base_url="http://127.0.0.1:8000/v1", api_key="anything")
  r = client.chat.completions.create(
      model="deepseek-chat",
      messages=[{"role": "user", "content": "Hello!"}],
  )
  print(r.choices[0].message.content)

MODELS:
  deepseek-chat              fast model
  deepseek-reasoner          DeepThink (R1-style reasoning)
  deepseek-expert            stronger/slower model
  deepseek-expert-reasoner   expert + thinking
  deepseek-chat-search       fast model + web search
  deepseek-reasoner-search   reasoning + web search

VISION: pass OpenAI-style image parts, e.g.
  {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,..."}}
  {"type": "image_url", "image_url": {"url": "https://.../pic.jpg"}}

Protect your server (optional):  export REST_API_KEY=my-secret
A ready-made chat UI is served at http://127.0.0.1:8000/
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import threading
import time
import uuid
from collections import OrderedDict
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

sys_path = str(Path(__file__).resolve().parent)
if sys_path not in sys.path:
    sys.path.insert(0, sys_path)

import deepseek_web_chat as dsw  # noqa: E402

TOKEN = os.environ.get("DEEPSEEK_USER_TOKEN", "")
API_KEY = os.environ.get("REST_API_KEY", "")  # optional: protect YOUR server

import tempfile
TMP_DIR = Path(tempfile.gettempdir()) / "ds_images"
TMP_DIR.mkdir(parents=True, exist_ok=True)

MODELS = {
    "deepseek-chat":            dict(model_type="default", thinking=False, search=False),
    "deepseek-reasoner":        dict(model_type="default", thinking=True,  search=False),
    "deepseek-expert":          dict(model_type="expert",  thinking=False, search=False),
    "deepseek-expert-reasoner": dict(model_type="expert",  thinking=True,  search=False),
    "deepseek-chat-search":     dict(model_type="default", thinking=False, search=True),
    "deepseek-reasoner-search": dict(model_type="default", thinking=True,  search=True),
}

app = FastAPI(title="DeepSeek Web REST API", version="1.0",
              docs_url="/swagger", redoc_url=None)

from fastapi.middleware.cors import CORSMiddleware  # noqa: E402

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                   allow_headers=["*"])

# conversation cache: json(messages-prefix) -> {"chat_session_id", "parent_id"}
_CONVS: OrderedDict[str, dict] = OrderedDict()
_CONV_LOCK = threading.Lock()


# --- data models -----------------------------------------------------------
class Message(BaseModel):
    role: str = "user"
    content: object = ""  # str or list of parts


class ChatRequest(BaseModel):
    model: str = "deepseek-chat"
    messages: list[Message]
    stream: bool = False
    # temperature / max_tokens etc. are accepted but ignored by the web API


class ModelCard(BaseModel):
    id: str
    object: str = "model"


# --- helpers ---------------------------------------------------------------
def check_auth(request: Request):
    if not API_KEY:
        return
    auth = request.headers.get("authorization", "")
    if auth != f"Bearer {API_KEY}":
        return JSONResponse({"error": {"message": "Invalid API key", "type": "auth"}},
                            status_code=401)


def err(msg: str, code: int = 500):
    return JSONResponse({"error": {"message": msg, "type": "server_error"}}, status_code=code)


def _save_temp_image(data: bytes, ext: str) -> str:
    p = TMP_DIR / f"{uuid.uuid4().hex}{ext}"
    p.write_bytes(data)
    return str(p)


def extract_prompt_and_images(messages: list[Message], resume: bool = False):
    """Flatten OpenAI messages -> (single prompt, list of image file paths).
    resume=True means we continue an existing web session, so only the LAST
    message is sent (the history already lives server-side).
    """
    if resume:
        messages = messages[-1:]
    lines, images = [], []
    for m in messages:
        role = m.role if m.role != "assistant" else "Assistant"
        content = m.content
        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            parts = []
            for part in content:
                if not isinstance(part, dict):
                    continue
                ptype = part.get("type", "")
                if ptype == "text":
                    parts.append(part.get("text", ""))
                elif ptype == "image_url":
                    url = (part.get("image_url") or {}).get("url", "")
                    path = _materialize_image(url)
                    if path:
                        images.append(path)
                    else:
                        parts.append("[image could not be loaded]")
            text = "\n".join(p for p in parts if p)
        else:
            text = str(content)
        lines.append(f"[{role}]: {text}" if len(messages) > 1 else text)
    # final user message is the prompt; earlier turns give context
    if len(messages) > 1:
        prompt = "\n".join(lines)
    else:
        prompt = lines[0] if lines else ""
    return prompt, images


def _materialize_image(url: str) -> str | None:
    try:
        if url.startswith("data:"):
            header, b64 = url.split(",", 1)
            ext = ".png" if "png" in header else ".jpg"
            return _save_temp_image(base64.b64decode(b64), ext)
        if url.startswith("http"):
            import curl_cffi.requests as creq

            r = creq.get(url, impersonate="chrome", timeout=30)
            ctype = r.headers.get("content-type", "image/jpeg")
            ext = ".png" if "png" in ctype else ".jpg"
            return _save_temp_image(r.content, ext)
    except Exception:
        return None
    return None


def _find_conv(messages) -> dict | None:
    key = json.dumps([m.model_dump() for m in messages[:-1]], ensure_ascii=False)
    with _CONV_LOCK:
        conv = _CONVS.get(key)
        if conv:
            _CONVS.move_to_end(key)
        return conv


def _store_conv(messages, reply_text: str, conversation_id: str):
    if ":" not in conversation_id:
        return
    sid, mid = conversation_id.rsplit(":", 1)
    if not mid.isdigit():
        return
    key = json.dumps([m.model_dump() for m in messages] +
                     [{"role": "assistant", "content": reply_text}], ensure_ascii=False)
    with _CONV_LOCK:
        _CONVS[key] = {"chat_session_id": sid, "parent_message_id": int(mid)}
        while len(_CONVS) > 300:
            _CONVS.popitem(last=False)


def _cfg_for(model: str) -> dict:
    cfg = MODELS.get(model)
    if cfg is None:  # tolerate unknown names -> default
        cfg = MODELS["deepseek-chat"]
    return cfg


# --- endpoints -------------------------------------------------------------
@app.get("/healthz")
def healthz():
    return {"status": "ok", "token_loaded": bool(TOKEN)}


@app.get("/models")
@app.get("/v1/models")
def list_models(request: Request):
    denied = check_auth(request)
    if denied:
        return denied
    return {"object": "list",
            "data": [{"id": mid, "object": "model", "owned_by": "deepseek-web"}
                     for mid in MODELS]}


@app.post("/chat/completions")
@app.post("/v1/chat/completions")
def chat_completions(body: ChatRequest, request: Request):
    denied = check_auth(request)
    if denied:
        return denied
    if not TOKEN:
        return err("Server missing DEEPSEEK_USER_TOKEN. Restart with --token <userToken>.")

    cfg = _cfg_for(body.model)
    conv = _find_conv(body.messages)
    prompt, images = extract_prompt_and_images(body.messages, resume=bool(conv))
    if not prompt.strip():
        return err("Empty prompt", 400)

    if not body.stream:
        try:
            text, reasoning = "", ""
            for kind, delta in dsw.stream_chat(
                    prompt, images=images, thinking=cfg["thinking"], search=cfg["search"],
                    expert=(cfg["model_type"] == "expert"), token=TOKEN, cookies=dict(dsw.COOKIES),
                    chat_session_id=(conv or {}).get("chat_session_id"),
                    parent_message_id=(conv or {}).get("parent_message_id")):
                if kind == "text":
                    text += delta
                else:
                    reasoning += delta
            conv_id = getattr(dsw.stream_chat, "conversation_id", "")
            if conv_id:
                _store_conv(body.messages, text, conv_id)
            msg = {"role": "assistant", "content": text}
            if reasoning:
                msg["reasoning_content"] = reasoning
            return {
                "id": "chatcmpl-" + uuid.uuid4().hex[:24],
                "object": "chat.completion",
                "created": int(time.time()),
                "model": body.model,
                "choices": [{"index": 0, "message": msg, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
                "deepseek_conversation_id": conv_id,
            }
        except Exception as e:
            return err(str(e))

    # ---- streaming (OpenAI SSE format) ----
    rid = "chatcmpl-" + uuid.uuid4().hex[:24]

    def gen():
        text_parts, reasoning_parts = [], []
        try:
            for kind, delta in dsw.stream_chat(
                    prompt, images=images, thinking=cfg["thinking"], search=cfg["search"],
                    expert=(cfg["model_type"] == "expert"), token=TOKEN, cookies=dict(dsw.COOKIES),
                    chat_session_id=(conv or {}).get("chat_session_id"),
                    parent_message_id=(conv or {}).get("parent_message_id")):
                if kind == "text":
                    text_parts.append(delta)
                    field = "content"
                else:
                    reasoning_parts.append(delta)
                    field = "reasoning_content"
                chunk = {
                    "id": rid, "object": "chat.completion.chunk",
                    "created": int(time.time()), "model": body.model,
                    "choices": [{"index": 0, "delta": {field: delta}, "finish_reason": None}],
                }
                yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
            conv_id = getattr(dsw.stream_chat, "conversation_id", "")
            if conv_id:
                _store_conv(body.messages, "".join(text_parts), conv_id)
        except Exception as e:
            chunk = {"id": rid, "object": "chat.completion.chunk",
                     "created": int(time.time()), "model": body.model,
                     "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                     "error": {"message": str(e)}}
            yield f"data: {json.dumps(chunk)}\n\n"
        final = {
            "id": rid, "object": "chat.completion.chunk",
            "created": int(time.time()), "model": body.model,
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        }
        yield f"data: {json.dumps(final)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


from docs_page import DOCS_HTML  # noqa: E402

# --- minimal chat UI -------------------------------------------------------
CHAT_UI = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DeepSeek Web Chat</title>
<style>
:root{--bg:#0f1117;--panel:#1a1d27;--line:#2a2e3d;--tx:#e8eaf2;--dim:#8b90a5;--acc:#4d6bfe}
*{box-sizing:border-box;margin:0}
body{font-family:system-ui,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--tx);height:100vh;display:flex;flex-direction:column}
header{display:flex;gap:10px;align-items:center;padding:12px 16px;border-bottom:1px solid var(--line);background:var(--panel)}
header h1{font-size:15px;font-weight:600;margin-right:auto}
select,input[type=password]{background:var(--bg);color:var(--tx);border:1px solid var(--line);border-radius:8px;padding:7px 10px;font-size:13px}
#log{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:14px}
.msg{max-width:78%;padding:11px 14px;border-radius:14px;line-height:1.55;white-space:pre-wrap;word-wrap:break-word;font-size:14px}
.user{align-self:flex-end;background:var(--acc);color:#fff;border-bottom-right-radius:4px}
.bot{align-self:flex-start;background:var(--panel);border:1px solid var(--line);border-bottom-left-radius:4px}
.bot .think{color:var(--dim);font-size:12.5px;border-left:2px solid var(--line);padding-left:9px;margin-bottom:7px;white-space:pre-wrap}
form{display:flex;gap:9px;padding:13px 16px;border-top:1px solid var(--line);background:var(--panel)}
textarea{flex:1;background:var(--bg);color:var(--tx);border:1px solid var(--line);border-radius:10px;padding:11px;font-size:14px;resize:none;font-family:inherit;height:46px}
button{background:var(--acc);border:0;color:#fff;border-radius:10px;padding:0 20px;font-size:14px;cursor:pointer}
button:disabled{opacity:.5}
#imgBtn{background:var(--bg);border:1px solid var(--line);border-radius:10px;width:46px}
.imgtag{font-size:12px;color:var(--dim);margin-top:4px}
</style></head><body>
<header><h1>DeepSeek Web Chat <span style="color:var(--dim);font-weight:400">(cookie-based, no API key)</span></h1>
<select id="model">
<option value="deepseek-chat">deepseek-chat</option>
<option value="deepseek-reasoner">deepseek-reasoner (thinking)</option>
<option value="deepseek-expert">deepseek-expert</option>
<option value="deepseek-chat-search">deepseek-chat-search</option>
</select></header>
<div id="log"></div>
<form id="f"><button type="button" id="imgBtn" title="attach image">🖼</button>
<input type="file" id="img" accept="image/*" hidden>
<textarea id="t" placeholder="Type a message… (Enter to send)"></textarea>
<button id="send">Send</button></form>
<script>
const log=document.getElementById('log'),t=document.getElementById('t'),f=document.getElementById('f'),
send=document.getElementById('send'),model=document.getElementById('model'),
imgIn=document.getElementById('img'),imgBtn=document.getElementById('imgBtn');
let hist=[],pendingImg=null,apiKey=localStorage.getItem('dskey')||'';
if(!apiKey){apiKey=prompt('Optional: enter REST_API_KEY (leave blank if not set)')||'';localStorage.setItem('dskey',apiKey)}
imgBtn.onclick=()=>imgIn.click();
imgIn.onchange=()=>{if(imgIn.files[0]){const r=new FileReader();r.onload=()=>pendingImg=r.result;r.readAsDataURL(imgIn.files[0])}};
function add(role,txt,img){const d=document.createElement('div');d.className='msg '+role;
if(img){const i=document.createElement('div');i.className='imgtag';i.textContent='🖼 image attached';d.appendChild(i)}
const s=document.createElement('span');s.textContent=txt;d.appendChild(s);log.appendChild(d);log.scrollTop=log.scrollHeight;return s}
f.onsubmit=async e=>{e.preventDefault();const q=t.value.trim();if(!q)return;
t.value='';send.disabled=true;
add('user',q,pendingImg);
const parts=[{type:'text',text:q}];
if(pendingImg)parts.push({type:'image_url',image_url:{url:pendingImg}});
hist.push({role:'user',content:parts});
const think=model.value.includes('reasoner');
const botEl=add('bot','');let thinkEl=null;
if(think){thinkEl=document.createElement('div');thinkEl.className='think';botEl.appendChild(thinkEl)}
const span=document.createElement('span');botEl.appendChild(span);botEl._txt=span;
let full='';
try{const res=await fetch('/v1/chat/completions',{method:'POST',
headers:{'Content-Type':'application/json',...(apiKey?{Authorization:'Bearer '+apiKey}:{})},
body:JSON.stringify({model:model.value,messages:hist,stream:true})});
const rd=res.body.getReader(),dec=new TextDecoder();let buf='';
while(true){const{done,value}=await rd.read();if(done)break;buf+=dec.decode(value,{stream:true});
const lines=buf.split('\\n');buf=lines.pop();
for(const ln of lines){if(!ln.startsWith('data:'))continue;const d=ln.slice(5).trim();
if(d==='[DONE]')continue;
try{const j=JSON.parse(d);if(j.error){span.textContent+='\\n[ERROR] '+j.error.message;continue}
const dl=j.choices[0].delta;
if(dl.reasoning_content&&thinkEl)thinkEl.textContent+=dl.reasoning_content;
if(dl.content){span.textContent+=dl.content;full+=dl.content;log.scrollTop=log.scrollHeight}}catch{}}}
hist.push({role:'assistant',content:full});
}catch(err){span.textContent='[ERROR] '+err.message}
pendingImg=null;imgIn.value='';send.disabled=false;t.focus()};
t.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();f.requestSubmit()}};
t.focus();
</script></body></html>"""


@app.get("/", response_class=HTMLResponse)
def index():
    return CHAT_UI


@app.get("/docs", response_class=HTMLResponse)
def docs(request: Request):
    proto = request.headers.get("x-forwarded-proto", request.url.scheme)
    host = request.headers.get("x-forwarded-host", request.headers.get("host", ""))
    base = f"{proto}://{host}"
    return DOCS_HTML.replace("__BASE__", base)


def main():
    global TOKEN
    ap = argparse.ArgumentParser(description="OpenAI-compatible REST API for DeepSeek web chat")
    ap.add_argument("--token", default=TOKEN, help="userToken from chat.deepseek.com localStorage")
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8000)),
                    help="port (default: $PORT env, else 8000)")
    ap.add_argument("--host", default=os.environ.get("HOST", "0.0.0.0"),
                    help="bind host (default: 0.0.0.0, required for Railway/Docker)")
    args = ap.parse_args()
    TOKEN = args.token or os.environ.get("DEEPSEEK_USER_TOKEN", "")
    if not TOKEN:
        print("WARNING: no token given; pass --token <userToken> or set DEEPSEEK_USER_TOKEN")
    import uvicorn

    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
